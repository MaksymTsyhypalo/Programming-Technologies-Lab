﻿using System;
using TP.InformationComputation.LayeredArchitecture.Logic;
using TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface;

namespace LayeredArchitecture.Runner
{
    class Program
    {
        static void Main(string[] args)
        {
            var serviceC = new ServiceC();
            var serviceB = new ServiceB(serviceC);
            var serviceA = new ServiceA(serviceB);

            double input = 3;
            Console.WriteLine($"Math Chain for {input}:");
            Console.WriteLine($"1. Square:       {serviceC.Calculate(input)}");  // 9
            Console.WriteLine($"2. Add 10:      {serviceB.Calculate(input)}");  // 19
            Console.WriteLine($"3. Double:      {serviceA.Calculate(input)}");  // 38
        }
    }
}