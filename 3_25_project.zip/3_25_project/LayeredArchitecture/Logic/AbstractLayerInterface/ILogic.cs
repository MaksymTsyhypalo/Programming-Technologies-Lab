﻿
namespace TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface
{
  public interface ILogic
  {
    IService? NextService { get; }
  }
}