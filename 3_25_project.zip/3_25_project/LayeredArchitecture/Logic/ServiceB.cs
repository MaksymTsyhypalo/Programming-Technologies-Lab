﻿

using TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface;

namespace TP.InformationComputation.LayeredArchitecture.Logic
{
    
    public class ServiceB : IService
    {
        public ServiceB(ServiceC service)
        {
            Service = service;
        }

        public IService? Service { get; set; }

        public double Calculate(double input)
        {
            // Get result from ServiceC and add 10
            return Service!.Calculate(input) + 10;  // e.g., 9 → 19
        }
    }
}