﻿

using TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface;

namespace TP.InformationComputation.LayeredArchitecture.Logic
{
    
    public class ServiceC : IService
    {
        public IService? Service { get; set; }

        public double Calculate(double input)
        {
            return input * input;  // Squares the input (e.g., 3 → 9)
        }
    }
}