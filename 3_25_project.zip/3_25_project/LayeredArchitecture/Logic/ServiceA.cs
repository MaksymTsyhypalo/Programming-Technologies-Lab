﻿

using TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface;

namespace TP.InformationComputation.LayeredArchitecture.Logic
{
    
    public class ServiceA : IService
    {
        public ServiceA(ServiceB? serviceB)
        {
            Service = serviceB;
        }

        public IService? Service { get; set; }

        public double Calculate(double input)
        {
            // Get result from ServiceB and double it
            return Service!.Calculate(input) * 2;  // e.g., 19 → 38
        }
    }
}