﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TP.InformationComputation.LayeredArchitecture.Logic;

namespace LayeredArchitecture.Tests
{
    [TestClass]
    public class ServiceSmokeTests
    {
        [TestMethod]
        public void ServiceInitialization_ShouldCreateValidChain()
        {
            // Arrange
            var serviceC = new ServiceC();

            // Act
            var serviceB = new ServiceB(serviceC);
            var serviceA = new ServiceA(serviceB);

            // Assert
            Assert.IsNotNull(serviceA.Service, "ServiceA should reference ServiceB");
            Assert.IsNotNull(serviceB.Service, "ServiceB should reference ServiceC");
            Assert.IsNull(serviceC.Service, "ServiceC should have no dependencies");
        }
    }
}