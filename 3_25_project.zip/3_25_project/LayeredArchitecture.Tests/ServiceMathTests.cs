﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TP.InformationComputation.LayeredArchitecture.Logic;
using TP.InformationComputation.LayeredArchitecture.Logic.AbstractLayerInterface;

namespace LayeredArchitecture.Tests
{
    [TestClass]
    public class ServiceMathTests
    {
        // Test 1
        [TestMethod]
        public void ServiceC_Calculate_SquaresInput()
        {
            var service = new ServiceC();
            Assert.AreEqual(25, service.Calculate(5));  // 5² = 25
            Assert.AreEqual(0, service.Calculate(0));   // 0² = 0
        }

        

        // Test 2
        [TestMethod]
        public void FullChain_Calculate_ProcessesCorrectly()
        {
            var serviceC = new ServiceC();
            var serviceB = new ServiceB(serviceC);
            var serviceA = new ServiceA(serviceB);

            Assert.AreEqual(38, serviceA.Calculate(3));  // 3²=9 → 9+10=19 → 19*2=38
        }
    }
}